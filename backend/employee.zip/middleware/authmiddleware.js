const jwt = require('jsonwebtoken')
const asyncHandler = require('express-async-handler')
const User = require('../models/usermodels')


const protected = async(req , res , next) => {
    
    let token 
    if(req.headers.Authorization && req.headers.Authorization.startsWith('Bearer')){

        try {
            
            //getting the token from header 
            token = req.headers.Authorization.split('')[1]
            

            //decoding the token 
            const decoded = jwt.verify(token , process.env.jwt_secret)


            //getting the user form the token               exclude the password 
            req.User = await User.findById(decoded.id).select('-password')

            //running the next piece of middleware 
            next()
        } 
        catch (error) { 
            res.json({message: 'not authorized'})
           console.log(error) 
        }
    }

    if(!token){
        res.status(401).json({message:'Not Authorized , no Token'})
    }
}


module.exports = protected