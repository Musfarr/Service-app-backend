const express = require('express')
const {GetUser , RegisterUser , LoginUser , UpdateUser } = require('../controllers/usercontroller')

const{Protected} = require("../middleware/authmiddleware")

const router = express.Router()


router.route('/').post(RegisterUser)
router.route('/login').post(LoginUser)
router.route('/').put(UpdateUser)

router.route('/me').get(GetUser )

module.exports = router