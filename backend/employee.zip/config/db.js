const mongoose = require('mongoose');

const ConnectDb = async () => {
    try {
        const con = await mongoose.connect('mongodb://localhost:27017/test_db');
        console.log(`mongo : ${con.connection.host}`.cyan.underline); // Access host through connection object
    } catch (error) {
        console.error(error);
        process.exit(1);
    }
}

module.exports = ConnectDb;